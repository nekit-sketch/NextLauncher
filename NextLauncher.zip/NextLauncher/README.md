# Next Launcher — шаг 0 (скелет)

Файлы:
- 01_PROJECT_STRUCTURE.md — дерево пакетов + решения по производительности
- settings.gradle.kts, build.gradle.kts, gradle/libs.versions.toml, app/build.gradle.kts, app/proguard-rules.pro
- app/src/main/AndroidManifest.xml

Манифест ссылается на классы/ресурсы, которые появятся в следующих модулях
(Application, MainActivity, xml/accessibility_service_config, xml/device_admin, xml/file_paths, темы).
До их написания проект не соберётся — это нормально для шага 0.
