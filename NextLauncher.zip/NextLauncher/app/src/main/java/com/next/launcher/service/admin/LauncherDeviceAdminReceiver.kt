package com.next.launcher.service.admin

import android.app.admin.DeviceAdminReceiver

class LauncherDeviceAdminReceiver : DeviceAdminReceiver()
