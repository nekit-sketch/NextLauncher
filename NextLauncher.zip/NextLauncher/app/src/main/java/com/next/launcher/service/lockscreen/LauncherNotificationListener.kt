package com.next.launcher.service.lockscreen

import android.service.notification.NotificationListenerService

/** Заглушка: уведомления на локскрине (модуль «Локскрин»). */
class LauncherNotificationListener : NotificationListenerService()
