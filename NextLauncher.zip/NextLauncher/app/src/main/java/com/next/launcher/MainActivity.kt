package com.next.launcher

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.next.launcher.ui.home.HomeScreen
import com.next.launcher.ui.theme.LauncherTheme
import dagger.hilt.android.AndroidEntryPoint

/** HOME-активити: edge-to-edge + Compose. */
@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent { LauncherTheme { HomeScreen() } }
    }
}
