package com.next.launcher.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Заглушка: после загрузки поднимем локскрин-сервис и расписание профилей. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) = Unit
}
