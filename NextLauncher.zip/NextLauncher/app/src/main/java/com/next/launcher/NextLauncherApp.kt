package com.next.launcher

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

/** Точка входа Hilt. Тяжёлую инициализацию сюда не кладём — старт лаунчера должен быть быстрым. */
@HiltAndroidApp
class NextLauncherApp : Application()
