package com.next.launcher.service.schedule

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Заглушка: смена профиля рабочего стола по расписанию. */
class ProfileAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) = Unit
}
