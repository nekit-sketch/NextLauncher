package com.next.launcher.service.lockscreen

import android.os.Bundle
import androidx.activity.ComponentActivity

/** Заглушка модуля «Локскрин». */
class LockScreenActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        finish()
    }
}
