package com.next.launcher.ui.settings

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.Text
import com.next.launcher.ui.theme.LauncherTheme

/** Заглушка: настройки появятся в модуле «Настройки». */
class SettingsActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LauncherTheme { Text("Settings — скоро") } }
    }
}
