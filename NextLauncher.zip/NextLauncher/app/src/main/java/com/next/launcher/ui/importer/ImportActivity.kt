package com.next.launcher.ui.importer

import android.os.Bundle
import androidx.activity.ComponentActivity

/** Заглушка: импорт тем/пресетов будет в модулях «Темы» и «Анимации». */
class ImportActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        finish()
    }
}
