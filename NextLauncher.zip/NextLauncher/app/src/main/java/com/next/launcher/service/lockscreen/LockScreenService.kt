package com.next.launcher.service.lockscreen

import android.app.Service
import android.content.Intent
import android.os.IBinder

/** Заглушка модуля «Локскрин». Позже: foreground + ресивер SCREEN_OFF. */
class LockScreenService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        stopSelf()
        return START_NOT_STICKY
    }
}
