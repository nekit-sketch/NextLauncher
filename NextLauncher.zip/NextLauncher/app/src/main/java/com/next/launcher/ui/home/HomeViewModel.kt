package com.next.launcher.ui.home

import android.content.ComponentName
import android.content.Context
import android.content.pm.LauncherApps
import android.os.Process
import android.os.UserHandle
import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@Immutable
data class AppItem(val label: String, val component: ComponentName, val icon: ImageBitmap)

/** Список приложений через LauncherApps (не нужен QUERY_ALL_PACKAGES) + автообновление при установке/удалении. */
@HiltViewModel
class HomeViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
) : ViewModel() {

    private val launcherApps = context.getSystemService(LauncherApps::class.java)
    private val _apps = MutableStateFlow<List<AppItem>>(emptyList())
    val apps: StateFlow<List<AppItem>> = _apps.asStateFlow()

    private val callback = object : LauncherApps.Callback() {
        override fun onPackageRemoved(packageName: String?, user: UserHandle?) = load()
        override fun onPackageAdded(packageName: String?, user: UserHandle?) = load()
        override fun onPackageChanged(packageName: String?, user: UserHandle?) = load()
        override fun onPackagesAvailable(packageNames: Array<out String>?, user: UserHandle?, replacing: Boolean) = load()
        override fun onPackagesUnavailable(packageNames: Array<out String>?, user: UserHandle?, replacing: Boolean) = load()
    }

    init {
        launcherApps.registerCallback(callback)
        load()
    }

    private fun load() {
        viewModelScope.launch(Dispatchers.IO) {
            val px = (56 * context.resources.displayMetrics.density).toInt()
            _apps.value = launcherApps.getActivityList(null, Process.myUserHandle())
                .filter { it.componentName.packageName != context.packageName }
                .map { AppItem(it.label.toString(), it.componentName, it.getIcon(0).toBitmap(px, px).asImageBitmap()) }
                .sortedBy { it.label.lowercase() }
        }
    }

    fun launch(item: AppItem) {
        launcherApps.startMainActivity(item.component, Process.myUserHandle(), null, null)
    }

    override fun onCleared() {
        launcherApps.unregisterCallback(callback)
    }
}
