# --- AppWidgetHost: провайдеры виджетов сериализуются как ComponentName/ID, не рефлексией, но держим на всякий ---
-keep class android.appwidget.** { *; }
-keepclassmembers class * extends android.appwidget.AppWidgetProvider { *; }

# --- kotlinx.serialization (пресеты анимаций, темы, бэкапы) ---
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.**
-keepclassmembers class com.next.launcher.** {
    *** Companion;
}
-keepclasseswithmembers class com.next.launcher.** {
    kotlinx.serialization.KSerializer serializer(...);
}
-keep,includedescriptorclasses class com.next.launcher.**$$serializer { *; }

# --- Room entities (имена колонок через аннотации, но защищаемся от обфускации моделей бэкапа) ---
-keep class com.next.launcher.data.db.entity.** { *; }

# --- Сервисы/ресиверы из манифеста ---
-keep class com.next.launcher.service.** { *; }

# --- Hilt/WorkManager Workers ---
-keep class * extends androidx.work.ListenableWorker { <init>(...); }
