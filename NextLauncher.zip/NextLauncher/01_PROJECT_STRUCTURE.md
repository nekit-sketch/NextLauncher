# Next Launcher — структура проекта

Single-module на старте (быстрее сборка, проще). Границы слоёв держим пакетами;
при росте выносим `:core:*`, `:feature:*` — пакеты уже раскладываются 1:1.
Trade-off: multi-module даёт параллельную сборку, но на старте это лишний boilerplate.

```
app/src/main/java/com/next/launcher/
├── NextLauncherApp.kt              # @HiltAndroidApp, Coil ImageLoader, WorkManager init
├── MainActivity.kt                 # HOME-активити, edge-to-edge, хост Compose + AppWidgetHost lifecycle
│
├── core/
│   ├── di/                         # Hilt-модули: DatabaseModule, DataStoreModule, DispatchersModule, WidgetModule
│   ├── common/                     # Result, DispatcherProvider, Extensions
│   ├── haptics/HapticManager.kt    # Сила вибрации по типу действия
│   └── perf/PowerModeMonitor.kt    # Battery-saver режим (<20%) → отключает тяжёлые анимации
│
├── data/
│   ├── apps/
│   │   ├── LauncherAppsSource.kt   # LauncherApps API + Callback (вместо PACKAGE_ADDED receiver)
│   │   ├── AppCategoryResolver.kt  # ApplicationInfo.category + fallback-эвристики
│   │   └── UsageTracker.kt         # Свой счётчик запусков (без UsageStats)
│   ├── db/
│   │   ├── LauncherDatabase.kt
│   │   ├── entity/                 # AppEntity, FolderEntity, HomeItemEntity, DockItemEntity, ProfileEntity
│   │   └── dao/
│   ├── datastore/
│   │   ├── SettingsDataStore.kt    # Preferences: простые настройки
│   │   ├── ComplexStore.kt         # JSON (kotlinx.serialization): пресеты анимаций, темы, жесты
│   │   └── serializer/
│   ├── icons/
│   │   ├── IconPackManager.kt      # ADW/Nova/Go формат: appfilter.xml
│   │   ├── IconFetcher.kt          # Coil Fetcher: pkg → Drawable → Bitmap (+ рекраска/маска)
│   │   └── IconProcessor.kt        # monochrome, tint, grayscale, mask shapes
│   ├── widgets/
│   │   ├── WidgetHostManager.kt    # AppWidgetHost, allocate/bind/configure/delete
│   │   └── WidgetRepositoryImpl.kt
│   ├── weather/OpenMeteoApi.kt     # Retrofit-less: Ktor/HttpURLConnection, без ключа
│   ├── contacts/ContactsSearchSource.kt
│   ├── backup/
│   │   ├── BackupManager.kt        # JSON export/import через SAF
│   │   ├── AutoBackupWorker.kt     # WorkManager → SAF tree URI
│   │   └── NovaImporter.kt         # Импорт раскладки из Nova backup
│   └── repository/                 # Реализации интерфейсов из domain
│
├── domain/
│   ├── model/                      # AppInfo, HomeItem, Folder, GridConfig, AnimationSpecConfig, ThemeSpec, GestureAction…
│   ├── repository/                 # интерфейсы
│   └── usecase/                    # GetSortedApps, SearchApps(T9), ApplyProfileBySchedule, ToggleFocusMode…
│
├── service/
│   ├── lockscreen/
│   │   ├── LockScreenService.kt    # foreground-сервис, показывает overlay
│   │   ├── LockScreenActivity.kt   # showWhenLocked / turnScreenOn
│   │   └── LauncherNotificationListener.kt
│   ├── access/LauncherAccessibilityService.kt  # GLOBAL_ACTION_LOCK_SCREEN (double-tap to lock)
│   ├── admin/LauncherDeviceAdminReceiver.kt    # альтернатива для lockNow()
│   └── schedule/ProfileScheduler.kt            # AlarmManager/WorkManager: утро/день/вечер
│
├── ui/
│   ├── theme/                      # Color, Type, Shape, LauncherTheme, ThemeEngine (Material You + кастом)
│   ├── navigation/                 # LauncherNavHost
│   ├── home/                       # HomeScreen, HomeViewModel, GridLayout, FreeformLayout, DockBar, WidgetView, WidgetContextMenu, QuickSettingsSheet
│   ├── drawer/                     # DrawerScreen, DrawerViewModel, AppGrid, FolderView, SearchBar(T9)
│   ├── animation/
│   │   ├── LaunchAnimationEngine.kt   # открытие/закрытие приложений (ActivityOptions + overlay)
│   │   ├── AnimationLibrary.kt        # fade, scale, slide, container-transform, circular-reveal, blur, zoom, bezier
│   │   ├── AnimationPresets.kt        # Snappy, Smooth, Bouncy, Minimal, iOS-like, Material You
│   │   └── editor/                    # AnimationEditorScreen + live preview
│   ├── lockscreen/                 # ClockVariants (10+), LiquidGlass, PinPad, PatternView, NotificationList
│   ├── settings/                   # Экран на каждый раздел настроек
│   ├── theme_editor/
│   ├── folders/                    # grid / fan / stack
│   └── components/                 # Переиспользуемые composable (AppIcon, SpringMenu, BlurBox…)
│
app/src/test/                       # Unit: ViewModel, UseCase, Repository, IconProcessor
app/src/androidTest/                # UI: Home drag&drop, Drawer search, Widget bind flow
```

## Критично для производительности (<150 мс cold start, <120 МБ)
- Никаких тяжёлых операций в `Application.onCreate` — Room, Coil, WorkManager инициализируются лениво (`Lazy<>` / App Startup).
- Список приложений на старте — из Room-кэша мгновенно, затем фоновая сверка с `LauncherApps`.
- **Baseline Profile** обязателен (в build.gradle подключён `profileinstaller`; модуль `:baselineprofile` добавим позже) — даёт ~30% к холодному старту.
- Иконки: Coil memory cache ≤ 25% от лимита, disk cache 64 МБ; размер декодирования = размер сетки × density.
- Compose: `@Stable`/`@Immutable` модели, `key` в LazyGrid, `graphicsLayer` вместо recomposition для анимаций.
